%Name: DivideDataSets.m
%Randomly divide the data set in proportion  
function [objvalue]=SecondDerivative(X)
objvalue=diff(X,2,2);