%Name: DivideDataSets.m
%Randomly divide the data set in proportion  
function [objvalue]=FirstDerivative(X)
objvalue=diff(X,1,2);
